<?php
const DATA_FILENAME = "visits.json";
if (isset($_GET["name"])) {
	$name = $_GET["name"];  // 从网址参数中获取名字
	$data = json_decode(file_get_contents(DATA_FILENAME), true);  // 读取数据库
	if (!isset($data[$name])) {
		$data[$name] = 0;  // 如果名字不存在于数据库中，初始化为 0
	}
	$data[$name]++;  // 更新数据库的值
	file_put_contents(DATA_FILENAME, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));  // 写入数据库
}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>统计</title>
	</head>
	<body>
		<?php
		if (isset($_GET["name"])) {
			echo "<p>欢迎，" . htmlspecialchars($name) . "！您访问了本站 $data[$name] 次。</p>";
		}
		?>
		<form>
			<label for="name">名字：</label>
			<input type="text" id="name" name="name">
			<input type="submit" />
		</form>
	</body>
</html>
