// 插入footer模版
// 使用fetch API获取外部HTML片段
fetch('https://zwz{$rthSuffix}/cdn/footer.html')
	.then(response => response.text())
	.then(html => {
		// 将获取到的HTML片段插入到id为footerDiv的元素之后
		document.getElementById('footerDiv').insertAdjacentHTML('afterbegin', html);
});