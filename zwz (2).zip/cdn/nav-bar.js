document.addEventListener('DOMContentLoaded', function () {
    // 获取触发元素和对应的悬浮菜单元素
    
    // 通用的菜单处理函数
    function handleMenu(trigger, menu) {
        let timer;

        // 计算并设置菜单显示位置的函数
        function setPosition() {
            const rect = trigger.getBoundingClientRect();
            menu.style.left = `${rect.left-20}px`;
            menu.style.top = `${rect.bottom+5}px`;
        }

        // 鼠标进入触发元素时的事件处理函数
        function onTriggerEnter() {
            menu.style.display = 'block';
            setPosition();
        }

        // 鼠标离开触发元素时的事件处理函数
        function onTriggerLeave() {
            timer = setTimeout(function () {
                menu.style.display = 'none';
            }, 1000);
        }

        // 鼠标进入菜单区域时的事件处理函数
        function onMenuEnter() {
            clearTimeout(timer);
        }

        // 鼠标离开菜单区域时的事件处理函数
        function onMenuLeave() {
            timer = setTimeout(function () {
                menu.style.display = 'none';
            }, 500);
        }

        // 添加事件监听器
        trigger.addEventListener('mouseenter', onTriggerEnter);
        trigger.addEventListener('mouseleave', onTriggerLeave);
        menu.addEventListener('mouseenter', onMenuEnter);
        menu.addEventListener('mouseleave', onMenuLeave);
    }

	const blogTrigger = document.getElementById('blog-trigger');
	const blogHoverMenu = document.getElementById('blog-hover-menu');
	const moreTrigger = document.getElementById('more-trigger');
	const moreHoverMenu = document.getElementById('more-hover-menu');
	// 为博客菜单添加交互逻辑
    handleMenu(blogTrigger, blogHoverMenu);
    // 为更多菜单添加交互逻辑
    handleMenu(moreTrigger, moreHoverMenu);
    
});