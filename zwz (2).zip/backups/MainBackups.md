# 主页代码备份
## 2024.12.7  
### /index.html
```PHP
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>主页 | 钟伟哲的网页</title>
    <style>
        /* 这里可以添加一些基础的样式，比如设置页面整体背景颜色等 
        body {
            font-family: Arial, sans-serif;
            background-color: #7bbfea;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #006c54;
            color: white;
            text-align: center;
            padding: 20px;
        }

        section {
            padding: 20px;
            margin: 20px;
            background-color: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
        }*/
		
    </style>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <!-- 网页头部，通常放置网站标题、导航栏等 -->
    <header>

    	<h1>欢迎来到我的网站</h1>
		<p>这是钟伟哲的个人网站，现部署于热铁盒网址托管</p>
		<!--
		<p><img src="https://badges.toozhao.com/badges/01JEFXD6Z4B5K9GYQC4D15C8JP/green.svg" / alt="流量统计图片"></p>
		-->
	</header>
	<ul class="nav-bar">
		<li><p style="color:black;font-weight: bold">网址导航</p></li>
		<li><p><a href="/index.html">首页</a></p></li>
		<li><p><a href="blog/studynotes/index.html">学习笔记</a></p></li>
		<li><p><a href="blog/index.html">个人博客</a></p></li>
		<li><p><a href="https://www.luogu.com.cn/user/1053876">洛谷个人主页</a></p></li>
	</ul>
    <!-- 主体内容部分 -->
	<section> 
		<img src="https://api.xecades.xyz/api?img=2&date=2025-07-19&str=%E6%88%91%E7%9A%84%E7%94%9F%E6%97%A5&email=730518867%40qq.com&luogu=zwz6666&qq=730518867&codeforces=Zhong_wz" alt="">
	</section>
    <section>
    	<h2>关于本人</h2>
		<ul>
    		<li><p>初二生，现就读于湖南师大思沁。</p></li>
			<li><p>学校化竞队、信竞队、丘少班成员。</p></li>
			<li><p>CSP-J 一等*2。</p></il>
			<li><p style="color:ffffff;">成绩一般，不上不下。</p></li>
		</ul>
    </section>

    

    <section>
        <h2>最新消息</h2>
        <p>网页初步搭建完成，下一步待定！<br>就是希望能一直免费下去。</p>
    </section>
    <!-- 网页底部，可放置版权信息、联系方式等 -->
    <footer>
        &copy; <a href="https://www.luogu.com.cn/user/1053876" style="color:white;">钟伟哲</a> 版权所有<br>
		E-MALL : 730518867@qq.com
    </footer>
</body>

</html>
```

/styless.css
```php
body {
	font-family: Arial, sans-serif;
	background-color: #7bbfea;
	margin: 0;
	padding: 0;
	}

header {
	background-color: #13a686;
	color: white;
	text-align: center;
	padding: 20px;
}

section {
	padding: 20px;
	margin: 20px;
	background-color: white;
	box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
}

footer {
	background-color: #333;
	color: white;
	text-align: center;
	padding: 10px;
}

a {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}

//横向导航栏
       /* 清除默认样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* 导航栏整体样式，设置宽度范围 */
     .nav-bar {
            list-style-type: none;
            background-color: #f4f4f4;
            border: 1px solid #ccc;
            max-width: 1200px; /* 最大宽度为 1000 像素 */
            min-width: 600px; /* 最小宽度为 600 像素 */
            margin: 0 auto; /* 让导航栏在页面中水平居中 */
            display: flex;
            justify-content: space-around;
        }

        /* 列表项样式 */
     .nav-bar li {
            padding: 10px 20px;
        }

        /* 链接样式 */
     .nav-bar a {
            text-decoration: none;
            color: #333;
        }

        /* 鼠标悬停效果 */
     .nav-bar a:hover {
            color: #fff;
            background-color: #333;
        }
//横向导航栏 END
```
### 导航栏在下
```php

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="https://cdn.luogu.com.cn/upload/usericon/1053876.png">
    <title>主页 | 钟伟哲的网页</title>
    <style>
		//Nothing now.
    </style>
	<link rel="stylesheet" type="text/css" href="https://cdn.rthe.cn/cached-b5ca3f98f8c663abb70bf7fa17f0b99c-avif/zwz/styles.css">
	<script>
		var _hmt = _hmt || [];
		(function() {
		var hm = document.createElement("script");
		hm.src = "https://hm.baidu.com/hm.js?eafc4d903581ae4c434cea8cb45dc161";
		var s = document.getElementsByTagName("script")[0]; 
		s.parentNode.insertBefore(hm, s);
		})();
	</script>

</head>

<body>
	<span class="top-left-element"><a href="/index.html" style="color:black;">返回首页</a></span>
    <!-- 网页头部，通常放置网站标题、导航栏等 -->
    <header>

    	<h1>欢迎来到我的网站</h1>
		<p>这是钟伟哲的个人网站，现部署于热铁盒网页托管</p>
		
		<!--//统计图片
		<p><img src="https://badges.toozhao.com/badges/01JEFXD6Z4B5K9GYQC4D15C8JP/green.svg" / alt="流量统计图片"></p>
		-->
		
		<ul class="nav-bar">
		<li><p style="color:black;font-weight: bold">网址导航</p></li>
		<li><p><a href="/help.html">帮助</a></p></li>
		<li><p><a href="/index.html">首页</a></p></li>
		<li><p><a href="blog/studynotes/index.html">学习笔记</a></p></li>
		<li><p><a href="blog/index.html">个人博客</a></p></li>
		<li><p><a href="https://www.luogu.com.cn/user/1053876">洛谷个人主页</a></p></li>
		</ul>
	</header>
	
    <!-- 主体内容部分 -->
	<section> 
		<img src="https://api.xecades.xyz/api?img=2&date=2025-07-19&str=%E6%88%91%E7%9A%84%E7%94%9F%E6%97%A5&email=730518867%40qq.com&luogu=zwz6666&qq=730518867&codeforces=Zhong_wz" alt="">
	</section>
    <section>
    	<h2>关于本人</h2>
		<ul>
    		<li><p>初二生，现就读于湖南师大思沁。</p></li>
			<li><p>学校化竞队、信竞队、丘少班成员。</p></li>
			<li><p>CSP-J 一等*2。</p>
			</li><li><p style="color:ffffff;">成绩一般，不上不下。</p></li>
		</ul>
    </section>

    

    <section>
        <h2>最新消息</h2>
        <p>网页初步搭建完成，下一步待定！</p>
    </section>
    <!-- 网页底部，可放置版权信息、联系方式等 -->
    <footer>
        © <a href="https://www.luogu.com.cn/user/1053876" style="color:white;">钟伟哲</a> 版权所有<br>
		E-MALL : 730518867@qq.com
    </footer>
</body>

</html>

```

## 2024.12.15

### /index.html
```
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="https://cdn.luogu.com.cn/upload/usericon/1053876.png">
    <title>主页 | 钟伟哲的网页</title>
    <style>
		//Nothing now.
    </style>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<script>
		var _hmt = _hmt || [];
		(function() {
		var hm = document.createElement("script");
		hm.src = "https://hm.baidu.com/hm.js?eafc4d903581ae4c434cea8cb45dc161";
		var s = document.getElementsByTagName("script")[0]; 
		s.parentNode.insertBefore(hm, s);
		})();
	</script>

</head>
    
<body>
	 <script>
       fetch('nav-bar.html')
      .then(response => response.text())
      .then(data => {
           document.body.insertAdjacentHTML('afterbegin', data);
         });
     </script>
	<!--<span class="top-left-element"><a href="/index.html" style="color:black;">返回首页</a></span>
    -->
	<!-- 网页头部，通常放置网站标题、导航栏等 -->
    <header>

    	<h1>欢迎来到我的网站</h1>
		<p>这是钟伟哲的个人网站，现部署于热铁盒网页托管</p>
		
		<!--//统计图片
		<p><img src="https://badges.toozhao.com/badges/01JEFXD6Z4B5K9GYQC4D15C8JP/green.svg" / alt="流量统计图片"></p>
		-->
		
	</header>
	
    <!-- 主体内容部分 -->
	<section>
		<h1>临时置顶</h1>
		<p style="font-size:50px">2024年12月9日,我,洛谷,<a style="color:red;font-size:60px">首次红了！！</a></p>
	</section>

	<section> 
		<img src="https://api.xecades.xyz/api?img=2&date=2025-07-19&str=%E6%88%91%E7%9A%84%E7%94%9F%E6%97%A5&email=730518867%40qq.com&luogu=zwz6666&qq=730518867&codeforces=Zhong_wz" alt="">
	</section>
    <section>
    	<h2>关于本人</h2>
		<ul>
    		<li><p>初二生，现就读于湖南师大思沁。</p></li>
			<li><p>学校化竞队、信竞队、丘少班成员。</p></li>
			<li><p>CSP-J 一等*2。</p></il>
			<li><p style="color:#ffffff;">成绩一般，不上不下。</p></li>
		</ul>
    </section>

    

    <section>
        <h2>最新消息</h2>
        <p>网页初步搭建完成，下一步待定！</p>
    </section>
    <!-- 网页底部，可放置版权信息、联系方式等 -->
    <footer>
        &copy; <a href="https://www.luogu.com.cn/user/1053876" style="color:white;">钟伟哲</a> 版权所有<br>
		E-MALL : 730518867@qq.com
    </footer>
</body>

</html>
```

### /模版.html
```
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="https://cdn.luogu.com.cn/upload/usericon/1053876.png">
    <title>主页 | 钟伟哲的网页</title>
    <style>
		//Nothing now.
    </style>
	<link rel="stylesheet" type="text/css" href="styles.css">

</head>

<body>
	<span class="top-left-element"><a href="/index.html" style="color:black;">返回首页</a></span>
    <!-- 网页头部，通常放置网站标题、导航栏等 -->
    <header>

    	<h1>欢迎来到我的网站</h1>
		<p>这是钟伟哲的个人网站，现部署于热铁盒网页托管</p>
		
		<!--//统计图片
		<p><img src="https://badges.toozhao.com/badges/01JEFXD6Z4B5K9GYQC4D15C8JP/green.svg" / alt="流量统计图片"></p>
		-->
		
		<ul class="nav-bar">
		<li><p style="color:black;font-weight: bold">网址导航</p></li>
		<li><p><a href="/index.html">首页</a></p></li>
		<li><p><a href="blog/studynotes/index.html">学习笔记</a></p></li>
		<li><p><a href="blog/index.html">个人博客</a></p></li>
		<li><p><a href="https://www.luogu.com.cn/user/1053876">洛谷个人主页</a></p></li>
		</ul>
	</header>

    <!-- 网页底部，可放置版权信息、联系方式等 -->
    <footer>
        &copy; <a href="https://www.luogu.com.cn/user/1053876" style="color:white;">钟伟哲</a> 版权所有<br>
		E-MALL : 730518867@qq.com
    </footer>
</body>

</html>
```

### /blog/studynotes/1.html
```
<script>MathJax = { tex: {inlineMath: [['$', '$'], ['\\(', '\\)']]}};</script><script id="MathJax-script" async src="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/mathjax/3.2.0/es5/tex-chtml.js"></script>


<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>2024.11.15 树状数组学习</title><link rel="stylesheet" href="https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-y/github-markdown-css/5.1.0/github-markdown.min.css"><style>.markdown-body{margin:30px;}</style></head><body class="markdown-body"><div class="markdown-heading"><h1 class="heading-element">2024.11.15 树状数组学习</h1><a id="user-content-20241115-树状数组学习" class="anchor" aria-label="Permalink: 2024.11.15 树状数组学习" href="#20241115-树状数组学习"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<div class="markdown-heading"><h2 class="heading-element">题目列表</h2><a id="user-content-题目列表" class="anchor" aria-label="Permalink: 题目列表" href="#题目列表"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<ul>
<li><a href="https://www.luogu.com.cn/problem/P3374" rel="nofollow">P3374 【模板】树状数组 1</a></li>
<li><a href="https://www.luogu.com.cn/problem/P3368" rel="nofollow">P3368 【模板】树状数组 2</a></li>
<li><a href="https://www.luogu.com.cn/problem/P4939" rel="nofollow">P4939 Agent2</a></li>
<li><a href="https://www.luogu.com.cn/problem/P5057" rel="nofollow">P5057 [CQOI2006] 简单题</a></li>
<li><a href="https://www.luogu.com.cn/problem/P1908" rel="nofollow">P1908 逆序对</a></li>
<li><a href="https://www.luogu.com.cn/problem/P1774" rel="nofollow">P1774 最接近神的人</a></li>
<li><a href="https://www.luogu.com.cn/problem/P2068" rel="nofollow">P2068 统计和</a></li>
<li><a href="https://www.luogu.com.cn/problem/P3655" rel="nofollow">P3655 不成熟的梦想家 (未熟 DREAMER)</a></li>
</ul>
<div class="markdown-heading"><h1 class="heading-element">以下是正文部分</h1><a id="user-content-以下是正文部分" class="anchor" aria-label="Permalink: 以下是正文部分" href="#以下是正文部分"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P3374" rel="nofollow">P3374 &lt;单点修改、区间查询模版&gt;</a></h2><a id="user-content-p3374-单点修改区间查询模版" class="anchor" aria-label="Permalink: P3374 &lt;单点修改、区间查询模版&gt;" href="#p3374-单点修改区间查询模版"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>板子1</p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">5e5</span>+<span class="pl-c1">5</span>;
<span class="pl-k">int</span> a[maxn],n,m;
#<span class="pl-k">define</span> <span class="pl-en">lowbit</span>(<span class="pl-v">x</span>) (x&amp;-x);
<span class="pl-k">void</span> <span class="pl-en">updata</span>(<span class="pl-k">int</span> x,<span class="pl-k">int</span> k){
	<span class="pl-k">while</span>(x&lt;=n){
		a[x]+=k; 
		x+=<span class="pl-c1">lowbit</span>(x);
	}
}
<span class="pl-k">int</span> <span class="pl-en">query</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">int</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x){
		ans+=a[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {
	cin&gt;&gt;n&gt;&gt;m;
	<span class="pl-k">int</span> x,y,z;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++){
		cin&gt;&gt;x;
		<span class="pl-c1">updata</span>(i,x);
	}
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=m;i++){
		cin&gt;&gt;z&gt;&gt;x&gt;&gt;y;
		<span class="pl-k">if</span>(z==<span class="pl-c1">1</span>)<span class="pl-c1">updata</span>(x,y);
		<span class="pl-k">else</span> cout&lt;&lt;(<span class="pl-c1">query</span>(y)-<span class="pl-c1">query</span>(x-<span class="pl-c1">1</span>))&lt;&lt;<span class="pl-s"><span class="pl-pds">"</span><span class="pl-cce">\n</span><span class="pl-pds">"</span></span>;
	}
	<span class="pl-k">return</span> <span class="pl-c1">0</span>;
}</pre></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P3368" rel="nofollow">P3368 &lt;区间修改、单点查询模版&gt;</a></h2><a id="user-content-p3368-区间修改单点查询模版" class="anchor" aria-label="Permalink: P3368 &lt;区间修改、单点查询模版&gt;" href="#p3368-区间修改单点查询模版"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>板子2</p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">5e5</span>+<span class="pl-c1">5</span>;
<span class="pl-k">int</span> a[maxn],b[maxn],n,m; 
<span class="pl-k">inline</span> <span class="pl-k">int</span> <span class="pl-en">lowbit</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">return</span> x&amp;-x;
}
<span class="pl-k">void</span> <span class="pl-en">add</span>(<span class="pl-k">int</span> i,<span class="pl-k">int</span> k){
	<span class="pl-k">while</span>(i&lt;=n){
		a[i]+=k;
		i+=<span class="pl-c1">lowbit</span>(i);
	}
}
<span class="pl-k">int</span> <span class="pl-en">query</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">int</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x){
		ans+=a[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {
	cin&gt;&gt;n&gt;&gt;m;
	<span class="pl-k">int</span> t,x,y,k;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++){
		cin&gt;&gt;b[i];
		<span class="pl-c1">add</span>(i,b[i]-b[i-<span class="pl-c1">1</span>]);
	}
	<span class="pl-c"><span class="pl-c">//</span>cout&lt;&lt;a[1]&lt;&lt;"\n";</span>
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=m;i++){
		cin&gt;&gt;t&gt;&gt;x;
		<span class="pl-k">if</span>(t==<span class="pl-c1">1</span>){
			cin&gt;&gt;y&gt;&gt;k;
			<span class="pl-c1">add</span>(x,k);
			<span class="pl-c1">add</span>(y+<span class="pl-c1">1</span>,-k);
		}
		<span class="pl-k">else</span> cout&lt;&lt;<span class="pl-c1">query</span>(x)&lt;&lt;<span class="pl-s"><span class="pl-pds">"</span><span class="pl-cce">\n</span><span class="pl-pds">"</span></span>;
	}
	<span class="pl-k">return</span> <span class="pl-c1">0</span>;
}
</pre></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P4939" rel="nofollow">P4939 Agent2&lt;区间修改、单点查询&gt;</a></h2><a id="user-content-p4939-agent2区间修改单点查询" class="anchor" aria-label="Permalink: P4939 Agent2&lt;区间修改、单点查询&gt;" href="#p4939-agent2区间修改单点查询"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>这道题依旧很板子，与<code>P3368</code>很相似。也是区间修改、单点查询，每次修改的值为 $1$  ，使用差分维护即可。</p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">1e7</span>+<span class="pl-c1">5</span>;
<span class="pl-k">int</span> a[maxn];
#<span class="pl-k">define</span> <span class="pl-en">lowbit</span>(<span class="pl-v">x</span>) (x&amp;-x)
<span class="pl-k">int</span> n,m;
<span class="pl-k">int</span> <span class="pl-en">query</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">int</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x&gt;<span class="pl-c1">0</span>){
		ans+=a[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">void</span> <span class="pl-en">add</span>(<span class="pl-k">int</span> x,<span class="pl-k">int</span> k){
	<span class="pl-k">while</span>(x&lt;=n){
		a[x]+=k;
		x+=<span class="pl-c1">lowbit</span>(x);
	}
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {

	cin&gt;&gt;n&gt;&gt;m;
	<span class="pl-k">int</span> f,x,y;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=m;i++) {
		cin&gt;&gt;f;
		<span class="pl-k">if</span>(f){
			cin&gt;&gt;x;
			cout&lt;&lt;<span class="pl-c1">query</span>(x)&lt;&lt;<span class="pl-s"><span class="pl-pds">"</span><span class="pl-cce">\n</span><span class="pl-pds">"</span></span>;
		}<span class="pl-k">else</span> {
			cin&gt;&gt;x&gt;&gt;y;
			<span class="pl-c1">add</span>(x,<span class="pl-c1">1</span>);
			<span class="pl-c1">add</span>(y+<span class="pl-c1">1</span>,-<span class="pl-c1">1</span>);
		}
	}
}</pre></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P5057" rel="nofollow">P5057 [CQOI2006] 简单题 &lt;区间修改、单点查询&gt;</a></h2><a id="user-content-p5057-cqoi2006-简单题-区间修改单点查询" class="anchor" aria-label="Permalink: P5057 [CQOI2006] 简单题 &lt;区间修改、单点查询&gt;" href="#p5057-cqoi2006-简单题-区间修改单点查询"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>注意到$1 \le m \le 5 \times 10^5$ , 数据范围很小，直接每次判断该点修改次数是奇数还是偶数即可。</p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">1e7</span>+<span class="pl-c1">5</span>;
<span class="pl-k">int</span> a[maxn];
#<span class="pl-k">define</span> <span class="pl-en">lowbit</span>(<span class="pl-v">x</span>) (x&amp;-x)
<span class="pl-k">int</span> n,m;
<span class="pl-k">int</span> <span class="pl-en">query</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">int</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x&gt;<span class="pl-c1">0</span>){
		ans+=a[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">void</span> <span class="pl-en">add</span>(<span class="pl-k">int</span> x,<span class="pl-k">int</span> k){
	<span class="pl-k">while</span>(x&lt;=n){
		a[x]+=k;
		x+=<span class="pl-c1">lowbit</span>(x);
	}
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {

	cin&gt;&gt;n&gt;&gt;m;
	<span class="pl-k">int</span> f,x,y;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=m;i++) {
		cin&gt;&gt;f;
		<span class="pl-k">if</span>(f==<span class="pl-c1">2</span>){
			cin&gt;&gt;x;
			cout&lt;&lt;(<span class="pl-c1">query</span>(x)%<span class="pl-c1">2</span>==<span class="pl-c1">0</span>?<span class="pl-c1">0</span>:<span class="pl-c1">1</span>)&lt;&lt;<span class="pl-s"><span class="pl-pds">"</span><span class="pl-cce">\n</span><span class="pl-pds">"</span></span>;
		}<span class="pl-k">else</span> {
			cin&gt;&gt;x&gt;&gt;y;
			<span class="pl-c1">add</span>(x,<span class="pl-c1">1</span>);
			<span class="pl-c1">add</span>(y+<span class="pl-c1">1</span>,-<span class="pl-c1">1</span>);
		}
	}
}</pre></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P1908" rel="nofollow">$\star$ <em>P1908</em> 逆序对 &lt;离散化+单点修改、区间查询&gt;</a></h2><a id="user-content-star-p1908-逆序对-离散化单点修改区间查询" class="anchor" aria-label="Permalink: $\star$ P1908 逆序对 &lt;离散化+单点修改、区间查询&gt;" href="#star-p1908-逆序对-离散化单点修改区间查询"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>这题我就已经感到吃力<del>并且不会做</del>了。<br>
大体思路就是从小到大遍历，每次使用树状数组维护<strong>当前</strong>非逆序对,也就是:
$$
\sum_{j=1}^{a_i} {（大小=j的元素的个数）}
$$<br>
可以使用树状数组的前缀和计算。答案加上用本来的位置减去非逆序对的个数。<br>
由于元素范围达到了 $10^9$ ，所以需要使用离散化处理。<br>
另外：<br>
$$\large{不开long \ long 见祖宗}$$</p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
#<span class="pl-k">define</span> <span class="pl-en">lowbit</span>(<span class="pl-v">x</span>) (x&amp;-x)
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">5e5</span>+<span class="pl-c1">5</span>;
<span class="pl-k">struct</span> <span class="pl-en">node</span>{
	<span class="pl-k">int</span> num,i;
}a[maxn];
<span class="pl-k">int</span> t[maxn];
<span class="pl-k">int</span> n,m[maxn];
<span class="pl-k">bool</span> <span class="pl-en">cmp</span>(node a,node b){
	<span class="pl-k">if</span>(a.<span class="pl-smi">num</span>==b.<span class="pl-smi">num</span>)<span class="pl-k">return</span> a.<span class="pl-smi">i</span>&lt;b.<span class="pl-smi">i</span>;
	<span class="pl-k">return</span> a.<span class="pl-smi">num</span>&lt;b.<span class="pl-smi">num</span>;
}
<span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">add</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">while</span>(x&lt;=n){
		t[x]++;
		x+=<span class="pl-c1">lowbit</span>(x);
	}
}
<span class="pl-k">int</span> <span class="pl-en">query</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">int</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x){
		ans+=t[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {
	cin&gt;&gt;n;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++){
		cin&gt;&gt;a[i].<span class="pl-smi">num</span>;
		a[i].<span class="pl-smi">i</span>=i;
	}
	<span class="pl-k">long</span> <span class="pl-k">long</span> ans=<span class="pl-c1">0</span>;
	<span class="pl-c1">sort</span>(a+<span class="pl-c1">1</span>,a+n+<span class="pl-c1">1</span>,cmp);
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++)m[a[i].<span class="pl-smi">i</span>]=i;
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++){
		<span class="pl-c1">add</span>(m[i]);
		ans+=i-<span class="pl-c1">query</span>(m[i]);
	}
	cout&lt;&lt;ans;
	<span class="pl-k">return</span> <span class="pl-c1">0</span>;
}
</pre></div>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P1774" rel="nofollow">P1774 最接近神的人 &lt;逆序对&gt;</a></h2><a id="user-content-p1774-最接近神的人-逆序对" class="anchor" aria-label="Permalink: P1774 最接近神的人 &lt;逆序对&gt;" href="#p1774-最接近神的人-逆序对"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>和上面一个一样的，代码都不用改,就不放了。</p>
<div class="markdown-heading"><h2 class="heading-element"><a href="https://www.luogu.com.cn/problem/P3655" rel="nofollow">$\star$P3655 不成熟的梦想家 (未熟 DREAMER) </a></h2><a id="user-content-starp3655-不成熟的梦想家-未熟-dreamer-" class="anchor" aria-label="Permalink: $\star$P3655 不成熟的梦想家 (未熟 DREAMER) " href="#starp3655-不成熟的梦想家-未熟-dreamer-"><span aria-hidden="true" class="octicon octicon-link"></span></a></div>
<p>这是一道好题目啊。<del>虽然没能独立做出来</del><br>
首先，魅力值的计算方式很像差分，并且一个数值只与前后两个有关。<br>
而当修改时，区间内的差不会改变，但是两端的显然不会不变。只需要更新两个区间端点即可。<br>
不过需要注意，当右端点下标等于 $n$ 时，不需要更新。不过如果没有判断，由于正常单点查询并计算差值时，结果会为 $0$ ，也就相当于没有更新，仍然可以AC。<br>
还有就是如果想要去除本来的绝对值符号一定要注意判断正负。<del>否则你连样例都过不了</del></p>
<div class="highlight highlight-source-c++"><pre>#<span class="pl-k">include</span><span class="pl-s"><span class="pl-pds">&lt;</span>bits/stdc++.h<span class="pl-pds">&gt;</span></span>
<span class="pl-k">using</span> <span class="pl-k">namespace</span> <span class="pl-en">std</span><span class="pl-k">;</span>
#<span class="pl-k">define</span> <span class="pl-en">ll</span> <span class="pl-k">long</span> <span class="pl-k">long</span>
<span class="pl-k">const</span> <span class="pl-k">int</span> maxn = <span class="pl-c1">5e5</span>+<span class="pl-c1">5</span>;
ll a[maxn],b[maxn],n,m,s,t; 
<span class="pl-k">inline</span> ll <span class="pl-en">lowbit</span>(<span class="pl-k">int</span> x){
	<span class="pl-k">return</span> x&amp;-x;
}
<span class="pl-k">void</span> <span class="pl-en">add</span>(ll i,ll k){
	<span class="pl-k">while</span>(i&lt;=n){
		a[i]+=k;
		i+=<span class="pl-c1">lowbit</span>(i);
	}
}
ll <span class="pl-en">query</span>(ll x){
	ll ans=<span class="pl-c1">0</span>;
	<span class="pl-k">while</span>(x){
		ans+=a[x];
		x-=<span class="pl-c1">lowbit</span>(x);
	}
	<span class="pl-k">return</span> ans;
}
<span class="pl-k">inline</span> ll <span class="pl-en">f</span>(ll x){
	<span class="pl-k">return</span> x&gt;<span class="pl-c1">0</span>?-s*x:-t*x;
}
<span class="pl-k">int</span> <span class="pl-en">main</span>() {
	cin&gt;&gt;n&gt;&gt;m&gt;&gt;s&gt;&gt;t;
	ll x,y,z,ans=<span class="pl-c1">0</span>;
	cin&gt;&gt;b[<span class="pl-c1">0</span>];
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=n;i++){
		cin&gt;&gt;b[i];
		<span class="pl-c1">add</span>(i,b[i]-b[i-<span class="pl-c1">1</span>]);
		ans+=<span class="pl-c1">f</span>(b[i]-b[i-<span class="pl-c1">1</span>]);
	}
	<span class="pl-k">for</span>(<span class="pl-k">int</span> i=<span class="pl-c1">1</span>;i&lt;=m;i++){
		cin&gt;&gt;x&gt;&gt;y&gt;&gt;z;
		ans-=<span class="pl-c1">f</span>(<span class="pl-c1">query</span>(x)-<span class="pl-c1">query</span>(x-<span class="pl-c1">1</span>));
		<span class="pl-c"><span class="pl-c">/*</span>if(y&lt;n)<span class="pl-c">*/</span></span>ans-=<span class="pl-c1">f</span>(<span class="pl-c1">query</span>(y+<span class="pl-c1">1</span>)-<span class="pl-c1">query</span>(y));
		
		<span class="pl-c1">add</span>(x,z);
		<span class="pl-c1">add</span>(y+<span class="pl-c1">1</span>,-z);
		
		ans+=<span class="pl-c1">f</span>(<span class="pl-c1">query</span>(x)-<span class="pl-c1">query</span>(x-<span class="pl-c1">1</span>));
		<span class="pl-c"><span class="pl-c">/*</span>if(y&lt;n)<span class="pl-c">*/</span></span>ans+=<span class="pl-c1">f</span>(<span class="pl-c1">query</span>(y+<span class="pl-c1">1</span>)-<span class="pl-c1">query</span>(y));
		
		cout&lt;&lt;ans&lt;&lt;<span class="pl-s"><span class="pl-pds">"</span><span class="pl-cce">\n</span><span class="pl-pds">"</span></span>;
	}
	<span class="pl-k">return</span> <span class="pl-c1">0</span>;
}</pre></div>
<hr>
<p>原始链接：<a href="https://www.luogu.com.cn/article/0jyh7tel" rel="nofollow">https://www.luogu.com.cn/article/0jyh7tel</a></p>
</body></html>
```